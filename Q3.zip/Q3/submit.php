<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "simple-form";

if(isset($_POST['submit'])){
    $name = $_POST['Name'];
    $mNumber = $_POST['mobileNumber'];


$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}

$sql = "INSERT INTO  formdata (name, mobileNumber) VALUES ('$Name','$mNumber')";

if ($conn->query($sql) === TRUE) {
    
  echo "<div class='popBg'></div>";
  echo "<p class='confirm'>New record created successfully <br> <a href='index.php' class='back'>Back to Form</a> </p>";

} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Chain Reaction Task</title>
  <link rel="stylesheet" href="css/style.css">
</head>
<body>
  
</body>
</html>