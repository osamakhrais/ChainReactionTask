<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
    <title>Chain Reaction Task</title>
</head>

<body>
    <div class="wrapper">
        <div class="container-custom">
            <form action="submit.php" method="post">
                <div class="form-caption">
                    <h2>Hello, who's this?</h2>
                </div>
                <div class="input-field">
                    <label for="">Name: </label>
                    <input type="text" name="firstName" placeholder="Name" required>
                </div>
                <!-- <div class="input-field">
                    <label for="">Last Name: </label>
                    <input type="text" name="lastName" placeholder="Enter Last Name" required>
                </div> -->
                <div class="input-field">
                    <label for="">Phone Number: </label>
                    <input type="text" name="mobileNumber" placeholder="Phone number" required>
                </div>
                <div class="input-field">
                    <input type="submit" name="submit" class="submitBtn" value="Submit">
                </div>

            </form>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>

    <script>
        $('.popBg').click(function(){
            $('.popBg, p.confirm').hide()
        })
    </script>
</body>

</html>